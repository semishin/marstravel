
// A $( document ).ready() block.
$( document ).ready(function() {

    $(window).load(function() {
        if($('.index_page').length>0){
            setTimeout(function() {
                $(".index_page").addClass("blur");
                $(".index_page").addClass("visible");
            }, 1200);
        }


        if( ($('.slider .right_part').length>0) && ($('.tour').length>0)){
            var img_height = $(".tour").height();
            var img_width = $(".slider .right_part").width();
            $(".tour .right_part .image img").width(img_width+30);
            $(".tour .right_part .image img").height(img_height);
        }
        if( ($('.left_menu').length>0) && ($('.tour').length>0)){
            var height = $(".tour").height();
            $(".left_menu>ul").height(height);
        }
        if( ($('.left_banner').length>0) && ($('.tour').length>0)){
            var height = $(".tour").height();
            $(".left_block .left_banner").height(height);
        }

        if($('#any_id').length>0){
            var slider_height = $("#any_id>.barousel_image>img").height();
            $("#any_id").height(slider_height);
        }


    });
    if($('.index_page').length>0){
        var w_width = $(".index_page .content").width();
        var w_height = $(".index_page .content").height();
        $(".index_page>.background_image").width(w_width+6);
        $(".index_page>.background_image").height(w_height+6);
    }


    $(".certificate .two_buttons .left_btn").hover(
        function () {
            $(".index_page").removeClass("blur");
        },
        function () {
            $(".index_page").addClass("blur");
        }
    );
    $(".certificate .two_buttons .right_btn").hover(
        function () {
            $(".index_page").addClass("grayscale");
        },
        function () {
            $(".index_page").removeClass("grayscale");
        }
    );


    $('.carousel').carousel({
        interval: false
    })

    if( $('.slider .right_part').length>0 ){
        $(".carousel-indicators>li").click(function () {
            var slide_number = $(this).data('slide-to');
            $(".right_part .slide_text.active").removeClass('active');
            $(".right_part .slide_text.text"+slide_number).addClass('active');
        });
    }

    $('.tooltip_icon').tooltip();

    $(".fancy").fancybox();

    var counter1 = 0;
    var counter2 = 0;

    $(".counter1>.btn-group>button:first-child").click(function () {
        if(counter1>0)
            counter1--;
        $("#adult_number").val(counter1);
    });
    $(".counter1>.btn-group>button:last-child").click(function () {
        counter1++;
        $("#adult_number").val(counter1);
    });

    $(".counter2>.btn-group>button:first-child").click(function () {
        if(counter2>0)
            counter2--;
        $("#children_number").val(counter2);
    });
    $(".counter2>.btn-group>button:last-child").click(function () {
        counter2++;
        $("#children_number").val(counter2);
    });


    if($('input[name="daterange"]').length>0){
        $('input[name="daterange"]').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true
        });
    }


    if($('#any_id').length>0){

        $('#any_id').barousel({
            navType: 2,
            fadeIn: 1,
            manualCarousel: 1
        });

        var image_width = $("#any_id").width();
        $("#any_id>.barousel_image>img").width(image_width);
    }


    $.fn.equalizeHeights = function() {
        var maxHeight = this.map(function(i,e) {
            return $(e).height();
        }).get();

        return this.height( Math.max.apply(this, maxHeight) );
    };

    $('.hotels_block').each(function(i,elem) {
        $(this).find('.hotel .name').equalizeHeights();
    });

    $('.sights_block').each(function(i,elem) {
        $(this).find('.sight .name').equalizeHeights();
    });


    if($('.selectpicker').length>0){
        //$('.selectpicker').selectpicker();
    }

    if($('.filter').length>0){
       /* $('.filter input').iCheck({
            checkboxClass: 'icheckbox_minimal',
            radioClass: 'iradio_minimal',
            increaseArea: '20%' // optional
        });*/
    }

    $('.lightbox_form .red_btn').click(function(e) {
        e.preventDefault();
        var errors = 0;
        var f_id = $(this).data('id');
        //alert("data-id="+f_id)
        if($('.lightbox_form[data-id='+f_id+'] input[name="name"]').length>0){
            var name = $('.lightbox_form[data-id='+f_id+'] input[name="name"]').val();
            //alert("name="+name);
            if (!name) {
                $('.lightbox_form[data-id='+f_id+'] input[name=name]').addClass('error');
                errors++;
            } else {
                $('.lightbox_form[data-id='+f_id+'] input[name=name]').removeClass('error');
            }
        }
        if($('.lightbox_form[data-id='+f_id+'] input[name="email"]').length>0){
            var email = $('.lightbox_form[data-id='+f_id+'] input[name="email"]').val();
            //alert("email="+email);
            if (!email) {
                $('.lightbox_form[data-id='+f_id+'] input[name=email]').addClass('error');
                errors++;
            } else {
                $('.lightbox_form[data-id='+f_id+'] input[name=email]').removeClass('error');
            }
        }
        if($('.lightbox_form[data-id='+f_id+'] input[name="phone"]').length>0){
            var phone = $('.lightbox_form[data-id='+f_id+'] input[name="phone"]').val();
            //alert("phone="+phone);
            if (!phone) {
                $('.lightbox_form[data-id='+f_id+'] input[name=phone]').addClass('error');
                errors++;
            } else {
                $('.lightbox_form[data-id='+f_id+'] input[name=phone]').removeClass('error');
            }
        }
        if($('.lightbox_form[data-id='+f_id+'] input[name="code"]').length>0){
            var code = $('.lightbox_form[data-id='+f_id+'] input[name="code"]').val();
            //alert("code="+code);
            if (!code) {
                $('.lightbox_form[data-id='+f_id+'] input[name=code]').addClass('error');
                errors++;
            } else {
                $('.lightbox_form[data-id='+f_id+'] input[name=code]').removeClass('error');
            }
        }
        if($('.lightbox_form[data-id='+f_id+'] textarea[name="question"]').length>0){
            var question = $('.lightbox_form[data-id='+f_id+'] textarea[name="question"]').val();
            //alert("question="+question);
            if (!question) {
                $('.lightbox_form[data-id='+f_id+'] textarea[name=question]').addClass('error');
                errors++;
            } else {
                $('.lightbox_form[data-id='+f_id+'] textarea[name=question]').removeClass('error');
            }
        }

        if (errors) {
            alert("error "+errors);
            return false;
        } else{
            switch (f_id) {
                case 0:
                    //alert("ajax method - "+f_id);
                    $.ajax({
                        url : " ",
                        dataType : "json",
                        type : "post",
                        data : {name : name, email : email, phone : phone, question : question},
                        success : function(jsondata) {
                            alert("Success");
                        },
                        error: function(xhr, status, error) {
                            alert(status + '|\n' +error);
                        }
                    });
                    break
                case 1:
                    //alert("ajax method - "+f_id);
                    $.ajax({
                        url : " ",
                        dataType : "json",
                        type : "post",
                        data : {name : name, email : email, phone : phone},
                        success : function(jsondata) {
                            alert("Success");
                        },
                        error: function(xhr, status, error) {
                            alert(status + '|\n' +error);
                        }
                    });
                    break
                case 2:
                    //alert("ajax method - "+f_id);
                    $.ajax({
                        url : " ",
                        dataType : "json",
                        type : "post",
                        data : {name : name, email : email, phone : phone, code : code},
                        success : function(jsondata) {
                            alert("Success");
                        },
                        error: function(xhr, status, error) {
                            alert(status + '|\n' +error);
                        }
                    });
                    break
                default:
                    alert('Я таких значений не знаю')
            }
        }
    });

    $('#cityhotel .selectpicker.form-control').change(function(e) {
        e.preventDefault();
        var city_id = $(this).find('option:selected').attr('data-id');
        $.ajax({
            type: "POST",
            url: "/hotel/city",
            data: {
                //offset: offset,
                city_id: city_id
            },
            dataType: 'json',
            success: function(result) {
                offset = 8;
                //$('.portfolio_buttons li button').removeClass('active');
                //$(this).addClass('active');
                $('.hotels_block .row').html(result.html);
                //if (!result.more) {
                //    $('#more_items').hide();
                //} else {
                //    $('#more_items').show();
                //}
            }
        });
    });

    $('#citystar .selectpicker.form-control').change(function(e) {
        e.preventDefault();
        var star = $(this).find('option:selected').val();
        $.ajax({
            type: "POST",
            url: "/hotel/star",
            data: {
                //offset: offset,
                star: star
            },
            dataType: 'json',
            success: function(result) {
                offset = 8;
                //$('.portfolio_buttons li button').removeClass('active');
                //$(this).addClass('active');
                $('.hotels_block .row').html(result.html);
                //if (!result.more) {
                //    $('#more_items').hide();
                //} else {
                //    $('#more_items').show();
                //}
            }
        });
    });

    $('#citysight .selectpicker.form-control').change(function(e) {
        e.preventDefault();
        var city_id = $(this).find('option:selected').attr('data-id');
        $.ajax({
            type: "POST",
            url: "/sight/city",
            data: {
                //offset: offset,
                city_id: city_id
            },
            dataType: 'json',
            success: function(result) {
                offset = 8;
                //$('.portfolio_buttons li button').removeClass('active');
                //$(this).addClass('active');
                $('.sights_block .row').html(result.html);
                //if (!result.more) {
                //    $('#more_items').hide();
                //} else {
                //    $('#more_items').show();
                //}
            }
        });
    });

    $('#categorysight .selectpicker.form-control').change(function(e) {
        e.preventDefault();
        var category = $(this).find('option:selected').attr('data-id');
        $.ajax({
            type: "POST",
            url: "/sight/category",
            data: {
                //offset: offset,
                category: category
            },
            dataType: 'json',
            success: function(result) {
                offset = 8;
                //$('.portfolio_buttons li button').removeClass('active');
                //$(this).addClass('active');
                $('.sights_block .row').html(result.html);
                //if (!result.more) {
                //    $('#more_items').hide();
                //} else {
                //    $('#more_items').show();
                //}
            }
        });
    });

});